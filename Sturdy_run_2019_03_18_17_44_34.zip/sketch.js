var d =8;
var n =5;
var sliderD;
var sliderN;


function setup(){
	createCanvas (400, 400);
	sliderD = createSlider(1,10,5);
	sliderN = createSlider(1,10,5);
}

function draw(){
	var k = sliderN.value()/sliderD.value();
	background(51);
	translate(width/2, height/2);

	beginShape();
	stroke(255);
	strokeWeight(1);
	
	for (var a =0;a < TWO_PI *10 ; a+=0.02) {
		var r =200 * cos(k*a);
		var x =r * cos(a);
		var y =r * sin(a);
		stroke(r,x*5,y*15);
		strokeWeight(10);
		point(x,y);
	}
	endShape(CLOSE);
}